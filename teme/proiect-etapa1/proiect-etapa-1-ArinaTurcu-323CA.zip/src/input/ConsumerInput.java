package input;

public final class ConsumerInput extends EntityInput {
    private int monthlyIncome;

    public int getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(final int monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }
}
